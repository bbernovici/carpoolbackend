package com.carpooling.service;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String CAR_POOLING_EXCHANGE = "car-pooling-exchange";
    public static final String USER_QUEUE = "user-queue";
    public static final String APP_QUEUE = "app-queue";

    @Bean
    Queue userQueue() {
        return new Queue(USER_QUEUE, false);
    }

    @Bean
    Queue appQueue() {
        return new Queue(APP_QUEUE, false);
    }

    @Bean
    TopicExchange exchange() {
        return new TopicExchange(CAR_POOLING_EXCHANGE);
    }

    @Bean
    Binding userBinding(Queue userQueue, TopicExchange exchange) {
        return BindingBuilder.bind(userQueue).to(exchange).with(USER_QUEUE);
    }

    @Bean
    Binding appBinding(Queue appQueue, TopicExchange exchange) {
        return BindingBuilder.bind(appQueue).to(exchange).with(APP_QUEUE);
    }

}
