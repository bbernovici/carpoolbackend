package com.carpooling.service.model;

public class User {
}
